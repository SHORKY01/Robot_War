#ifndef COMMON_H
#define COMMON_H
#include "TBot.h"


struct RobotInfo
{
    Robot *robot;
};

#endif//COMMON_H