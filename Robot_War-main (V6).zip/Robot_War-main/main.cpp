// main.cpp

#include "Grid.h"
#include "TBot.h"
#include "Queue.h"
#include "DerivedRobot.h"
#include <iostream>

using namespace std; // Use std namespace globally

int main()
{
    Grid grid(30, 20);
    Grid *gridPtr = &grid;

    // Create a queue for managing turns
    Queue<Robot *> turnQueue;

    // Initialize Robots
    RoboCop *robocop = new RoboCop("Robocop", 3, 0, 1, 1, gridPtr);
    Terminator *terminator = new Terminator("Terminator", 3, 0, 1, 2, gridPtr); //name, lives, kills, x, y, ptr
    TerminatorRoboCop *terminatorRC = new TerminatorRoboCop("ARC", 3, 0, 1, 4, gridPtr);
    // Add other robots here
    // Terminator* terminator = new Terminator(...);
    // TerminatorRobocop* terminatorRobocop = new TerminatorRobocop(...);
    // BlueThunder* blueThunder = new BlueThunder(...);
    // MadBot* madBot = new MadBot(...);
    // RoboTank* roboTank = new RoboTank(...);
    // UltimateRobot* ultimateRobot = new UltimateRobot(...);

    // Enqueue Robots
    turnQueue.enqueue(robocop);
    turnQueue.enqueue(terminator);
    turnQueue.enqueue(terminatorRC);
    // Enqueue other robots similarly
    // turnQueue.enqueue(terminator);
    // turnQueue.enqueue(terminatorRobocop);
    // turnQueue.enqueue(blueThunder);
    // turnQueue.enqueue(madBot);
    // turnQueue.enqueue(roboTank);
    // turnQueue.enqueue(ultimateRobot);

    // Display initial grid state
    grid.placeBot(robocop->getX(), robocop->getY(), robocop->getName()[0]);
    grid.placeBot(terminator->getX(), terminator->getY(), terminator->getName()[0]);
    grid.placeBot(terminatorRC->getX(), terminatorRC->getY(), terminatorRC->getName()[0]);
    // Place other Robots similarly...
    cout << "\n" << "Starting of Simulation: " << endl;

    grid.display();

    int turnNumber = 1;

    // Main game loop
    while (!turnQueue.isEmpty())
    {
        cout << "\nTurn " << turnNumber << endl; // Print current turn number

        // Process each bot's turn
        int numBots = turnQueue.size(); // Number of bots in the queue for this turn
        for (int i = 0; i < numBots; ++i)
        {
            Robot *currentRobot = turnQueue.dequeue();                     // Get the current robot's turn from the queue
            cout << "\nCurrent turn: " << currentRobot->getName() << endl; // Display current robot's turn

            // Use dynamic casting to call the Act method for each derived class
            if (RoboCop *robocop = dynamic_cast<RoboCop *>(currentRobot))
            {
                robocop->Act();
            }
            else if (Terminator *terminator = dynamic_cast<Terminator *>(currentRobot))
            {
                terminator->Act();
            }
            else if (TerminatorRoboCop *terminatorRC = dynamic_cast<TerminatorRoboCop *>(currentRobot))
            {
                terminatorRC->Act();
            }
            else{
                cout << "Error: Invalid Robot Type" << endl;
            }

            // Perform actions for the current robot (you can add more logic here)
            /*int choice;
            cout << "1 - Look" << endl
                 << "2 - Fire" << endl
                 << "3 - Move" << endl
                 << "4 - Step" << endl
                 << "Choice: ";
            cin >> choice;

            switch (choice)
            {
            case 1:
                if (SeeingRobot *seeingRobot = dynamic_cast<SeeingRobot *>(currentRobot))
                {
                    seeingRobot->Look(grid.getGrid(), grid.getWidth(), grid.getHeight());
                }
                else
                {
                    cout << "This robot can't perform the Look action!" << endl;
                }
                break;
            case 2:
                if (ShootingRobot *shootingRobot = dynamic_cast<ShootingRobot *>(currentRobot))
                {
                    shootingRobot->Fire(grid.getGrid(), grid.getWidth(), grid.getHeight());
                }
                else
                {
                    cout << "This robot can't perform the Fire action!" << endl;
                }
                break;
            case 3:
            {

                if (MovingRobot *movingRobot = dynamic_cast<MovingRobot *>(currentRobot))
                {
                    movingRobot->Move(gridPtr, 0, 0); // Move function will handle the new coordinates input
                }
                else
                {
                    cout << "This robot can't perform the Move action!" << endl;
                }
                break;
            }
            case 4:
                if (SteppingRobot *steppingRobot = dynamic_cast<SteppingRobot *>(currentRobot))
                {
                    steppingRobot->Step(gridPtr, 0, 0);
                }
                else
                {
                    cout << "This robot can't perform the Step action!" << endl;
                }
                break;
            default:
                cout << "Invalid Choice!" << endl;
                break;
            }

            // Enqueue the current robot back to the queue for the next turn*/
            turnQueue.enqueue(currentRobot);
        }

        // Prompt for user confirmation before proceeding to the next turn
        cout << "Press Enter to continue to the next turn...";
        cout << "Press Enter to continue to the next turn...";
        cin.ignore(); // Clear the input buffer
        cin.get();                                           // Wait for Enter key

        // Increment turn number for the next round
        turnNumber++;
    }

    // Clean up memory
    delete robocop;
    delete terminator;
    delete terminatorRC;
    // Delete other robots similarly...
    // delete terminator;
    // delete terminatorRobocop;
    // delete blueThunder;
    // delete madBot;
    // delete roboTank;
    // delete ultimateRobot;

    return 0;
}