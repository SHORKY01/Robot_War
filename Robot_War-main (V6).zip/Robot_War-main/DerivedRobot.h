#ifndef DERIVEDROBOT_H
#define DERIVEDROBOT_H

#include <iostream>
#include <string>
#include "TBot.h"

class RoboCop : public virtual Robot, public SeeingRobot, public ShootingRobot, public MovingRobot, public SteppingRobot
{ // inheritance
public:
    RoboCop(string _name, int _numOfLives, int _kills, int _x, int _y, Grid* _grid);
    virtual void Look(char** grid, int width, int height) override;
    virtual void Move(Grid* grid, int newX, int newY) override;
    virtual void Fire(char **grid, int width, int height) override;
    void Act();

    virtual ~RoboCop() {}
};

class Terminator : public virtual Robot, public SeeingRobot, public ShootingRobot, public MovingRobot, public SteppingRobot
{ // inheritance
public:
    Terminator(string _name, int _numOfLives, int _kills, int _x, int _y, Grid *_grid);
    virtual void Look(char** grid, int width, int height) override;
    virtual void Step(Grid* grid, int newX, int newY) override;
    void Act();

    virtual ~Terminator() {}
};

class TerminatorRoboCop : public virtual Robot, public SeeingRobot, public ShootingRobot, public MovingRobot, public SteppingRobot
{ // inheritance
public:
    TerminatorRoboCop(string _name, int _numOfLives, int _kills, int _x, int _y, Grid *_grid);
    virtual void Look(char **grid, int width, int height) override;
    virtual void Step(Grid *grid, int newX, int newY) override;
    virtual void Fire(char **grid, int width, int height) override;
    void Act();

    virtual ~TerminatorRoboCop() {}
};

class BlueThunder : public virtual Robot, public SeeingRobot, public ShootingRobot, public MovingRobot, public SteppingRobot
{ // inheritance
    int fireDirection;

public:
    BlueThunder(string _name, int _numOfLives, int _kills, int _x, int _y, Grid *_grid);
    virtual void Fire(char **grid, int width, int height) override;

    virtual ~BlueThunder() {}
};

class Madbot : public virtual Robot, public SeeingRobot, public ShootingRobot, public MovingRobot, public SteppingRobot
{ // inheritance
public:
    Madbot(string _name, int _numOfLives, int _kills, int _x, int _y, Grid *_grid);

    virtual ~Madbot() {}
};

class RoboTank : public virtual Robot, public SeeingRobot, public ShootingRobot, public MovingRobot, public SteppingRobot
{ // inheritance
public:
    RoboTank(string _name, int _numOfLives, int _kills, int _x, int _y, Grid *_grid);

    virtual ~RoboTank() {}
};

class UltimateRobot : public virtual Robot, public SeeingRobot, public ShootingRobot, public MovingRobot, public SteppingRobot
{ // inheritance
public:
    UltimateRobot(string _name, int _numOfLives, int _kills, int _x, int _y, Grid *_grid);

    virtual ~UltimateRobot() {}
};

#endif //DERIVEDROBOT.H